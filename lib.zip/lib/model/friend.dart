import 'package:splitpay/core/firestore_date.dart';

class Friend {
  final String id;
  final String name;
  final String avatarUrl;
  final String? phoneNumber;
  final String? linkedUid;
  final DateTime? createdAt;

  Friend({
    required this.id,
    required this.name,
    required this.avatarUrl,
    this.phoneNumber,
    this.linkedUid,
    this.createdAt,
  });

  factory Friend.fromFirestore(String id, Map<String, dynamic> data) {
    return Friend(
      id: id,
      name: data['name'] ?? '',
      avatarUrl: data['avatarUrl'] ?? '',
      phoneNumber: data['phoneNumber'],
      linkedUid: data['linkedUid'],
      createdAt: toDateTime(data['createdAt']),
    );
  }

  Map<String, dynamic> toFirestore(String ownerId) {
    return {
      'ownerId': ownerId,
      'name': name,
      'avatarUrl': avatarUrl,
      'phoneNumber': phoneNumber,
      'linkedUid': linkedUid,
      'createdAt': DateTime.now(),
    };
  }

  bool get isLinked => linkedUid != null;
}
