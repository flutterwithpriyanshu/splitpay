import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:splitpay/model/bill.dart';
import 'package:splitpay/model/friend.dart';
import 'package:splitpay/model/group.dart';
import 'package:splitpay/services/bill_service.dart';
import 'package:splitpay/services/friend_service.dart';
import 'package:splitpay/theme/app_colors.dart';
import 'package:splitpay/core/app_toast.dart';
import 'package:splitpay/widgets/local_avatar.dart';
import 'package:splitpay/screens/add_bill_screen.dart';
import 'package:splitpay/screens/edit_bill_screen.dart';
import 'package:splitpay/screens/bill_detail_screen.dart';
import 'package:splitpay/services/group_service.dart';
import 'package:splitpay/services/local_notification_service.dart';
import 'package:splitpay/widgets/day_of_month_picker.dart';
import 'package:splitpay/screens/group_splitup_screen.dart';
import 'package:splitpay/screens/group_settle_up/group_settle_up_screen.dart';
import 'package:splitpay/screens/edit_group_settings_screen.dart';
import 'package:splitpay/screens/group_details/widgets/header_pill.dart';
import 'package:splitpay/screens/group_details/widgets/balance_line_group_details.dart';
import 'package:splitpay/screens/group_details/widgets/tabs_row.dart';
import 'package:splitpay/core/app_currency.dart';

const _kMonthNames = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];
const _kMonthFullNames = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

String _monthAbbr(DateTime d) => _kMonthNames[d.month - 1];
String _dayPad(DateTime d) => d.day.toString().padLeft(2, '0');
String _monthYear(DateTime d) => '${_kMonthFullNames[d.month - 1]} ${d.year}';

class GroupDetailsScreen extends StatelessWidget {
  final Group group;

  const GroupDetailsScreen({super.key, required this.group});

  /// Net signed balance for this bill from the current user's point of
  /// view: positive = you are owed, negative = you owe. Uses the uid-based
  /// participant/payer data every group bill is actually saved with —
  /// NOT the legacy friendId/paidBy fields, which are unset on group bills
  /// and were causing every group bill to misreport as "you paid, settled".
  double _netForBill(Bill bill) {
    final myUid = FirebaseAuth.instance.currentUser?.uid;
    if (myUid == null) return 0;
    return bill.balanceForUid(myUid);
  }

  IconData _iconFor(String title) {
    final t = title.toLowerCase();
    if (t.contains('electric') || t.contains('water') || t.contains('light')) {
      return Icons.lightbulb_outline_rounded;
    }
    if (t.contains('petrol') || t.contains('fuel') || t.contains('gas')) {
      return Icons.local_gas_station_rounded;
    }
    if (t.contains('pizza') ||
        t.contains('dinner') ||
        t.contains('lunch') ||
        t.contains('breakfast') ||
        t.contains('food')) {
      return Icons.restaurant_rounded;
    }
    if (t.contains('rent') || t.contains('flat') || t.contains('home')) {
      return Icons.home_rounded;
    }
    if (t.contains('grocery') || t.contains('zepto') || t.contains('shop')) {
      return Icons.receipt_rounded;
    }
    if (t.contains('travel') ||
        t.contains('cab') ||
        t.contains('taxi') ||
        t.contains('uber')) {
      return Icons.local_taxi_rounded;
    }
    return Icons.receipt_long_rounded;
  }

  Color _iconBgFor(String title) {
    final t = title.toLowerCase();
    if (t.contains('electric') || t.contains('water') || t.contains('light')) {
      return const Color(0xFFDCEEFB);
    }
    if (t.contains('petrol') || t.contains('fuel') || t.contains('gas')) {
      return const Color(0xFFF9D8D8);
    }
    if (t.contains('pizza') ||
        t.contains('dinner') ||
        t.contains('lunch') ||
        t.contains('breakfast') ||
        t.contains('food')) {
      return const Color(0xFFDDF3E4);
    }
    return const Color(0xFFE9E7FB);
  }

  Color _iconColorFor(Color bg) => Colors.black.withValues(alpha: 0.55);

  /// Nets every bill down to one balance per group member, runs the debt
  /// simplifier over it, and shows the resulting "X pays Y ₹Z" list — the
  /// fewest payments needed to settle the whole group up.
  void _showSimplifiedDebts(
    BuildContext context,
    List<Bill> bills,
    List<Friend> members,
    Group currentGroup,
  ) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => GroupSplitupScreen(group: currentGroup),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Group>(
      stream: GroupService.streamGroup(group.id),
      initialData: group,
      builder: (context, groupSnapshot) {
        final currentGroup = groupSnapshot.data ?? group;
        return Scaffold(
          backgroundColor: AppColors.background,
          floatingActionButton: FloatingActionButton(
            onPressed: () {
              void onBillSaved() => Navigator.of(context).pop();

              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => AddBillScreen(
                    group: currentGroup,
                    onBillSaved: onBillSaved,
                  ),
                ),
              );
            },
            backgroundColor: AppColors.primary,
            child: const Icon(Icons.add_rounded, color: Colors.white),
          ),
          body: StreamBuilder<List<Friend>>(
            stream: FriendService.streamFriends(),
            builder: (context, friendSnapshot) {
              final friends = friendSnapshot.data ?? [];
              final members = friends
                  .where(
                    (f) =>
                        group.memberFriendIds.contains(f.id) &&
                        (!f.isLinked || group.memberUids.contains(f.linkedUid)),
                  )
                  .toList();

              return Column(
                children: [
                  _Header(group: currentGroup, members: members),
                  Expanded(
                    child: StreamBuilder<List<Bill>>(
                      stream: BillService.streamGroupBills(currentGroup.id),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        }
                        final bills = (snapshot.data ?? [])
                          ..sort((a, b) => b.date.compareTo(a.date));

                        double net = 0;
                        for (final bill in bills) {
                          net += _netForBill(bill);
                        }

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 14),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                              ),
                              child: GroupBalanceLine(
                                net: net,
                                members: members,
                              ),
                            ),
                            const SizedBox(height: 14),
                            GroupTabsRow(
                              onSettleUp: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (_) => GroupSettleUpScreen(
                                      group: currentGroup,
                                    ),
                                  ),
                                );
                              },
                              onBalances: () => _showSimplifiedDebts(
                                context,
                                bills,
                                members,
                                currentGroup,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Expanded(
                              child: bills.isEmpty
                                  ? Center(
                                      child: Text(
                                        'No bills in this group yet. Tap + to add one.',
                                        style: GoogleFonts.inter(
                                          fontSize: 13,
                                          color: AppColors.textSecondary,
                                        ),
                                      ),
                                    )
                                  : _BillList(
                                      bills: bills,
                                      iconFor: _iconFor,
                                      iconBgFor: _iconBgFor,
                                      iconColorFor: _iconColorFor,
                                      nameByUid: {
                                        for (final f in friends)
                                          if (f.isLinked) f.linkedUid!: f.name,
                                      },
                                    ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  final Group group;
  final List<Friend> members;

  const _Header({required this.group, required this.members});

  bool get _isOwner => group.ownerId == FirebaseAuth.instance.currentUser?.uid;

  Future<void> _editSettleUpDate(BuildContext context) async {
    final picked = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) =>
          DayOfMonthPicker(initialDay: group.settleUpDay, allowClear: true),
    );
    if (picked == null || !context.mounted) return;

    if (picked == -1) {
      await GroupService.updateSettleUpDay(group.id, null);
      await LocalNotificationService.cancelSettleReminder(group.id);
      if (context.mounted) {
        showAppToast(context, 'Settle up reminder turned off');
      }
      return;
    }

    await GroupService.updateSettleUpDay(group.id, picked);
    await LocalNotificationService.cancelSettleReminder(group.id);
    if (context.mounted) {
      showAppToast(context, 'You\'ll be reminded every month on day $picked');
    }
  }

  void _showMembers(BuildContext context) {
    final knownMemberUids = members
        .map((friend) => friend.linkedUid)
        .whereType<String>()
        .toSet();
    final additionalMemberUids = group.memberUids
        .where((uid) => uid != group.ownerId && !knownMemberUids.contains(uid))
        .toList();

    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${group.allMemberUids.length} people',
                  style: GoogleFonts.inter(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 16,
                  runSpacing: 12,
                  children: [
                    // Owner first — always part of the group.
                    SizedBox(
                      width: 64,
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 24,
                            backgroundColor: AppColors.primary.withValues(
                              alpha: 0.1,
                            ),
                            child: Icon(
                              Icons.person_rounded,
                              color: AppColors.primary.withValues(alpha: 0.4),
                              size: 24,
                            ),
                          ),
                          const SizedBox(height: 4),
                          FutureBuilder<String>(
                            future: FriendService.getUserName(group.ownerId),
                            builder: (context, snap) => Text(
                              '${snap.data ?? '...'} (owner)',
                              textAlign: TextAlign.center,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.inter(
                                fontSize: 11,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    ...members.map(
                      (friend) => SizedBox(
                        width: 64,
                        child: Column(
                          children: [
                            LocalAvatar(
                              localKey: friend.id,
                              isProfile: false,
                              fallbackUrl: friend.avatarUrl,
                              radius: 24,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              friend.name,
                              textAlign: TextAlign.center,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: GoogleFonts.inter(
                                fontSize: 11,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    ...additionalMemberUids.map(
                      (uid) => SizedBox(
                        width: 64,
                        child: Column(
                          children: [
                            CircleAvatar(
                              radius: 24,
                              backgroundColor: AppColors.primary.withValues(
                                alpha: 0.1,
                              ),
                              child: Icon(
                                Icons.person_rounded,
                                color: AppColors.primary.withValues(alpha: 0.4),
                                size: 24,
                              ),
                            ),
                            const SizedBox(height: 4),
                            FutureBuilder<String>(
                              future: FriendService.getUserName(uid),
                              builder: (context, snap) => Text(
                                snap.data ?? '...',
                                textAlign: TextAlign.center,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: GoogleFonts.inter(
                                  fontSize: 11,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primary, AppColors.secondary],
        ),
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 4, 12, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(
                      Icons.arrow_back_rounded,
                      color: Colors.white,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => EditGroupSettingsScreen(group: group),
                        ),
                      );
                    },
                    icon: const Icon(
                      Icons.settings_outlined,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(left: 12, top: 4, bottom: 16),
                child: Text(
                  group.name,
                  style: GoogleFonts.inter(
                    fontSize: 30,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 12),
                child: Row(
                  children: [
                    GroupHeaderPill(
                      icon: Icons.people_alt_rounded,
                      label: '${group.allMemberUids.length} people',
                      onTap: () => _showMembers(context),
                    ),
                    const SizedBox(width: 10),
                    Flexible(
                      child: GroupHeaderPill(
                        icon: Icons.calendar_today_rounded,
                        label: group.settleUpDay == null
                            ? (_isOwner
                                  ? 'Add settle up date'
                                  : 'Settle up date not set')
                            : 'Settle up on day ${group.settleUpDay}',
                        onTap: _isOwner
                            ? () => _editSettleUpDate(context)
                            : () => showAppToast(
                                context,
                                'Only the group owner can change the settle up date',
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BillList extends StatelessWidget {
  final List<Bill> bills;
  final IconData Function(String) iconFor;
  final Color Function(String) iconBgFor;
  final Color Function(Color) iconColorFor;
  final Map<String, String> nameByUid;

  const _BillList({
    required this.bills,
    required this.iconFor,
    required this.iconBgFor,
    required this.iconColorFor,
    required this.nameByUid,
  });

  @override
  Widget build(BuildContext context) {
    // Group bills by month/year, preserving the incoming (newest-first) sort.
    final grouped = <String, List<Bill>>{};
    for (final bill in bills) {
      final key = _monthYear(bill.date);
      grouped.putIfAbsent(key, () => []).add(bill);
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 88),
      itemCount: grouped.length,
      itemBuilder: (context, groupIndex) {
        final monthKey = grouped.keys.elementAt(groupIndex);
        final monthBills = grouped[monthKey]!;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 12, bottom: 8),
              child: Text(
                monthKey,
                style: GoogleFonts.inter(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
            ...monthBills.map(
              (bill) => _BillRow(
                bill: bill,
                icon: iconFor(bill.title),
                iconBg: iconBgFor(bill.title),
                iconColor: iconColorFor(iconBgFor(bill.title)),
                nameByUid: nameByUid,
              ),
            ),
          ],
        );
      },
    );
  }
}

class _BillRow extends StatelessWidget {
  final Bill bill;
  final IconData icon;
  final Color iconBg;
  final Color iconColor;
  final Map<String, String> nameByUid;

  const _BillRow({
    required this.bill,
    required this.icon,
    required this.iconBg,
    required this.iconColor,
    required this.nameByUid,
  });

  @override
  Widget build(BuildContext context) {
    final myUid = FirebaseAuth.instance.currentUser?.uid;
    // Who actually paid, per the real uid-based data every group bill is
    // saved with (falls back to the group owner when paidByUid is unset,
    // matching Bill.balanceForUid's own convention).
    final payerUid = bill.paidByUid ?? bill.ownerId;
    final youPaid = payerUid == myUid;

    // Signed from MY point of view: positive = I'm owed, negative = I owe.
    final net = myUid == null ? 0.0 : bill.balanceForUid(myUid);
    final isSettled = net.abs() <= 0.009;
    final ownShare =
        bill.sharesByUid[myUid] ?? (myUid == bill.ownerId ? bill.myShare : 0.0);
    // Payer: always show the full amount others owe. Others: always show
    // own share. Both stay fixed after settle or partial pay.
    double amount;
    if (youPaid) {
      final othersTotal = bill.sharesByUid.entries
          .where((e) => e.key != myUid)
          .fold<double>(0.0, (a, e) => a + e.value);
      amount = othersTotal > 0.009
          ? othersTotal
          : (bill.amount - ownShare).clamp(0.0, double.infinity).toDouble();
    } else {
      amount = ownShare;
    }
    final label = isSettled ? 'settled' : (net > 0 ? 'get' : 'pay');
    final amountColor = isSettled
        ? AppColors.success
        : (net > 0 ? AppColors.success : AppColors.error);
    final canManage = bill.ownerId == FirebaseAuth.instance.currentUser?.uid;

    Widget row = GestureDetector(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => BillDetailScreen(
              bill: bill,
              icon: icon,
              iconBg: iconBg,
              iconColor: iconColor,
            ),
          ),
        );
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              width: 40,
              child: Column(
                children: [
                  Text(
                    _monthAbbr(bill.date),
                    style: GoogleFonts.inter(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  Text(
                    _dayPad(bill.date),
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: iconBg,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: iconColor, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    bill.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    youPaid
                        ? 'You paid ${AppCurrency.symbol}${bill.amount.toStringAsFixed(0)}'
                        : '${nameByUid[payerUid] ?? 'A friend'} paid ${AppCurrency.symbol}${bill.amount.toStringAsFixed(0)}',
                    style: GoogleFonts.inter(
                      fontSize: 11,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  label,
                  style: GoogleFonts.inter(fontSize: 11, color: amountColor),
                ),
                Text(
                  '${AppCurrency.symbol}${amount.toStringAsFixed(2)}',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: amountColor,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );

    if (!canManage) return row;

    return Dismissible(
      key: ValueKey(bill.id),
      background: _swipeBackground(
        alignment: Alignment.centerLeft,
        color: AppColors.error,
        icon: Icons.delete_rounded,
      ),
      secondaryBackground: _swipeBackground(
        alignment: Alignment.centerRight,
        color: AppColors.primary,
        icon: Icons.edit_rounded,
      ),
      confirmDismiss: (direction) async {
        if (direction == DismissDirection.startToEnd) {
          final confirmed = await showDialog<bool>(
            context: context,
            builder: (dialogContext) => AlertDialog(
              title: const Text('Delete bill?'),
              content: const Text(
                'This bill will be removed for everyone in the group.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: const Text('Cancel'),
                ),
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, true),
                  child: const Text('Delete'),
                ),
              ],
            ),
          );
          if (confirmed == true) {
            try {
              await BillService.deleteBill(bill.id);
              return true;
            } catch (error) {
              if (context.mounted) showAppToast(context, error.toString());
            }
          }
          return false;
        } else {
          if (bill.settledFriendIds.isNotEmpty ||
              bill.settledUids.isNotEmpty ||
              bill.partialPaymentsByFriend.isNotEmpty ||
              bill.partialPaymentsByUid.isNotEmpty ||
              bill.myPartialPayment > 0) {
            showAppToast(
              context,
              'This bill has settled activity and can no longer be edited',
            );
          } else {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => EditBillScreen(bill: bill)),
            );
          }
          return false;
        }
      },
      child: row,
    );
  }

  Widget _swipeBackground({
    required Alignment alignment,
    required Color color,
    required IconData icon,
  }) {
    return Container(
      alignment: alignment,
      padding: const EdgeInsets.symmetric(horizontal: 24),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(icon, color: color),
    );
  }
}
