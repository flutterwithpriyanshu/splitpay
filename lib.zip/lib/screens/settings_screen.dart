import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:splitpay/core/app_toast.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:splitpay/core/static_content.dart';
import 'package:splitpay/core/profile_prefs.dart';
import 'package:splitpay/theme/theme_notifier.dart';
import 'package:splitpay/core/app_currency.dart';
import 'package:splitpay/screens/static_content_screen.dart';
import 'package:splitpay/theme/app_colors.dart';
import 'package:splitpay/widgets/edit_profile_screen.dart';
import 'package:splitpay/widgets/local_avatar.dart';
import 'package:splitpay/widgets/login_method_badge.dart';
import 'package:splitpay/widgets/manage_friends_screen.dart';
import 'package:splitpay/services/fcm_service.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:splitpay/screens/settings/widgets/settings_components.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _darkMode = false;
  String _currency = 'INR (₹)';
  String _language = 'English';

  Map<String, dynamic>? _profile;
  bool _loadingProfile = true;

  @override
  void initState() {
    super.initState();
    _darkMode = themeModeNotifier.value == ThemeMode.dark;
    _loadCurrency();
    _loadProfile();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final entry = _localeByLanguage.entries.firstWhere(
        (e) => e.value.languageCode == context.locale.languageCode,
        orElse: () => _localeByLanguage.entries.first,
      );
      if (mounted) setState(() => _language = entry.key);
    });
  }

  Future<void> _loadCurrency() async {
    final label = await CurrencyPrefs.getLabel();
    if (mounted) setState(() => _currency = label);
  }

  Future<void> _loadProfile() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) {
      setState(() => _loadingProfile = false);
      return;
    }
    try {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .get();
      setState(() {
        _profile = doc.data();
        _loadingProfile = false;
      });
    } catch (_) {
      setState(() => _loadingProfile = false);
    }
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Log out?',
          style: GoogleFonts.inter(fontWeight: FontWeight.w700),
        ),
        content: Text(
          'Are you sure you want to log out?',
          style: GoogleFonts.inter(
            fontSize: 13,
            color: AppColors.textSecondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(
              'Cancel',
              style: GoogleFonts.inter(color: AppColors.textSecondary),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(
              'logout'.tr(),
              style: GoogleFonts.inter(
                color: AppColors.error,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await FcmService.clearToken();
      await ProfilePrefs.clear();
      // Pop back to the root route FIRST. The root StreamBuilder in
      // main.dart lives there and swaps to AuthScreen on signOut, and
      // back to MainShell / CompleteProfileScreen on the next login.
      // Never push AuthScreen manually — that buries the StreamBuilder
      // and the next login gets stuck on the old AuthScreen.
      if (mounted) {
        Navigator.of(context).popUntil((route) => route.isFirst);
      }
      await FirebaseAuth.instance.signOut();
    }
  }

  void _showCurrencyPicker() {
    _showOptionSheet(
      title: 'currency'.tr(),
      options: kSupportedCurrencies,
      current: _currency,
      onSelect: (val) {
        setState(() => _currency = val);
        CurrencyPrefs.setLabel(val);
      },
    );
  }

  static const _localeByLanguage = {
    'English': Locale('en'),
    'Hindi': Locale('hi'),
    'Spanish': Locale('es'),
    'French': Locale('fr'),
  };

  void _showLanguagePicker() {
    _showOptionSheet(
      title: 'language'.tr(),
      options: const ['English', 'Hindi', 'Spanish', 'French'],
      current: _language,
      onSelect: (val) {
        setState(() => _language = val);
        final locale = _localeByLanguage[val];
        if (locale != null) context.setLocale(locale);
      },
    );
  }

  void _showOptionSheet({
    required String title,
    required List<String> options,
    required String current,
    required ValueChanged<String> onSelect,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                title,
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 12),
              ...options.map(
                (opt) => ListTile(
                  title: Text(opt, style: GoogleFonts.inter(fontSize: 14)),
                  trailing: opt == current
                      ? Icon(Icons.check_rounded, color: AppColors.primary)
                      : null,
                  onTap: () {
                    onSelect(opt);
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final name = _profile?['fullName'] ?? 'User';
    final phone = _profile?['phoneNumber'] ?? '-';
    final upiId = _profile?['upiId'] ?? '';

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          children: [
            Row(
              children: [
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.arrow_back_rounded),
                ),
                Text(
                  'settings'.tr(),
                  style: GoogleFonts.inter(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Profile card
            _loadingProfile
                ? SettingsSkeletonBox(
                    height: 90,
                    width: double.infinity,
                    radius: 20,
                  )
                : Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.04),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        LocalAvatar(
                          localKey:
                              FirebaseAuth.instance.currentUser?.uid ?? '',
                          isProfile: true,
                          radius: 30,
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                name,
                                style: GoogleFonts.inter(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Row(
                                children: [
                                  Flexible(
                                    child: Text(
                                      phone,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.inter(
                                        fontSize: 13,
                                        color: AppColors.textSecondary,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  const LoginMethodBadge(),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
            const SizedBox(height: 24),

            SettingsSectionTitle('Account'),
            SettingsTile(
              icon: Icons.person_rounded,
              label: 'Edit Profile',
              onTap: () async {
                final updated = await Navigator.of(context).push<bool>(
                  MaterialPageRoute(
                    builder: (_) => EditProfileScreen(
                      initialName: name,
                      initialPhone: phone,
                      initialUpi: upiId,
                    ),
                  ),
                );
                if (updated == true) _loadProfile(); // refresh after save
              },
            ),
            SettingsTile(
              icon: Icons.people_alt_rounded,
              label: 'Manage Friends',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => const ManageFriendsScreen(),
                  ),
                );
              },
            ),

            const SizedBox(height: 20),
            SettingsSectionTitle('Preferences'),
            SettingsSwitchTile(
              icon: Icons.dark_mode_rounded,
              label: 'dark_mode'.tr(),
              value: _darkMode,
              onChanged: (val) {
                setState(() => _darkMode = val);
                themeModeNotifier.value = val
                    ? ThemeMode.dark
                    : ThemeMode.light;
              },
            ),
            SettingsTile(
              icon: Icons.currency_exchange_rounded,
              label: 'currency'.tr(),
              trailing: _currency,
              onTap: _showCurrencyPicker,
            ),
            SettingsTile(
              icon: Icons.language_rounded,
              label: 'language'.tr(),
              trailing: _language,
              onTap: _showLanguagePicker,
            ),

            const SizedBox(height: 20),
            SettingsSectionTitle('Support'),
            SettingsTile(
              icon: Icons.help_center_rounded,
              label: 'Help Center',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => const StaticContentScreen(
                      title: 'Help Center',
                      content: helpCenterContent,
                    ),
                  ),
                );
              },
            ),
            SettingsTile(
              icon: Icons.privacy_tip_rounded,
              label: 'Privacy Policy',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => const StaticContentScreen(
                      title: 'Privacy Policy',
                      content: privacyPolicyContent,
                    ),
                  ),
                );
              },
            ),
            SettingsTile(
              icon: Icons.description_rounded,
              label: 'Terms & Conditions',
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => const StaticContentScreen(
                      title: 'Terms & Conditions',
                      content: termsContent,
                    ),
                  ),
                );
              },
            ),
            SettingsTile(
              icon: Icons.star_rounded,
              label: 'Rate App',
              onTap: () async {
                // Replace with your real Play Store URL once published
                final uri = Uri.parse(
                  'https://play.google.com/store/apps/details?id=com.SplitPay.app',
                );
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } else if (context.mounted) {
                  showAppToast(context, 'Could not open store link');
                }
              },
            ),

            const SizedBox(height: 24),
            SizedBox(
              height: 52,
              child: OutlinedButton(
                onPressed: _logout,
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: AppColors.error),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: Text(
                  'logout'.tr(),
                  style: GoogleFonts.inter(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: AppColors.error,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
